<php

protected $commands = [
    \App\Console\Commands\FixMigrations::class,
];
?>