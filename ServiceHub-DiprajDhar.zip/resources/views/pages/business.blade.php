@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h1 class="mb-4">Business</h1>
    <div class="alert alert-info">
        Business content coming soon!
    </div>
</div>
@endsection
