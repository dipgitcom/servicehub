@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h1 class="mb-4">Bondhu</h1>
    <div class="alert alert-info">
        Bondhu content coming soon!
    </div>
</div>
@endsection
