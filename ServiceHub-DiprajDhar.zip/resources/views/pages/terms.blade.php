@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h1 class="mb-4">Terms of Service</h1>
    <div class="alert alert-info">
        Terms of Service content coming soon!
    </div>
</div>
@endsection
