@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h1 class="mb-4">Help Center</h1>
    <div class="alert alert-info">
        Help content coming soon!
    </div>
</div>
@endsection
